# Database Setup (Supabase)

This setup uses a free, no-code PostgreSQL database called Supabase. It takes about 2 minutes to set up.

## 1. Create your Supabase Project
1. Go to [Supabase.com](https://supabase.com) and sign up for a free account.
2. Click **New Project**, name it `world-cup-tracker`, and create a database password.
3. Wait about 1-2 minutes for the database to finish setting up.

## 2. Create the Tables (The Easy Way)
Instead of clicking through menus, we can run one piece of code to create everything instantly.
1. In your Supabase dashboard, look at the left sidebar and click **SQL Editor**.
2. Click **New Query**.
3. Copy and paste the following code exactly as it is into the editor:

```sql
-- Create the 3 tables
create table matches (id text primary key, date text, team1 text, team2 text, deadline text);
create table predictions (id text primary key, "playerId" text, "matchId" text, score1 text, score2 text, winner text);
create table results ("matchId" text primary key, score1 text, score2 text, winner text);

-- Disable Row Level Security (RLS) so your HTML app can read/write freely without logins
alter table matches disable row level security;
alter table predictions disable row level security;
alter table results disable row level security;
```
4. Click the green **Run** button. You'll see a "Success" message.

## 3. Get Your API Keys
1. In the left sidebar, click the **Settings** gear icon at the bottom, then click **API**.
2. Look for your **Project URL** and copy it.
3. Look for your **Project API keys** and copy the one marked `anon` / `public`.

## 4. Connect the App
1. Open the `index.html` file in your browser (or upload it to GitHub Pages first).
2. Go to the **Database Setup** tab in the app.
3. Paste the URL and Anon Key you just copied.
4. Click **Connect & Save**. 

Your app is now live! The 9 players are already pre-loaded in the code. You can start adding matches and entering predictions.
